console.log("Esto es el script");



document.getElementById('res1').onclick = (function (evnt) {
let questionnumber = document.getElementById("total").value;

let formValid = document.getElementById('loginform');
   
answer = $("#test5").val();



   


});