$(document).ready(function(){
    $('select').formSelect();
  });

$(document).ready(function(){
    $('.sidenav').sidenav();
  });
