package com.psicocare.models;

public class Respuesta {
	
	private String respuestapaso;

}
