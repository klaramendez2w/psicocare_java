-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 05-12-2018 a las 15:08:49
-- Versión del servidor: 5.7.11
-- Versión de PHP: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `psicocare`
--
CREATE DATABASE IF NOT EXISTS `psicocare` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `psicocare`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividad`
--

CREATE TABLE `actividad` (
  `aid` int(11) NOT NULL,
  `statement` varchar(200) NOT NULL,
  `value` varchar(200) NOT NULL,
  `about` varchar(200) NOT NULL,
  `description` varchar(200) NOT NULL,
  `content` text NOT NULL,
  `countdown` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `actividad`
--

INSERT INTO `actividad` (`aid`, `statement`, `value`, `about`, `description`, `content`, `countdown`) VALUES
(1, 'your relationships', 'lonely', 'Sadness because one has no friends or company.', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Recusandae officiis necessitatibus blanditiis vero facilis neque nulla ducimus laboriosam. Est voluptates quaerat quae fuga recusandae saepe ne', 'podcast clench.mp3', 0),
(2, 'take it easy', 'depressed', 'A mental condition characterized by feelings of severe despondency and dejection, typically also with feelings of inadequacy and guilt, often accompanied by lack of energy and disturbance of appetite ', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam quo nobis nulla minima sed et, consequuntur aspernatur dolore nisi similique inventore voluptate non doloremque tempore debitis repudian', 'texarea', 0),
(3, 'keep calm', 'anxious', 'A nervous disorder marked by excessive uneasiness and apprehension, typically with compulsive behaviour or panic attacks', 'The following vide shows a series of tips that you can apply on your daily rutine in order to manage your stress and anxiety levels.', 'videorelax.mp4', 0),
(4, 'work out your goals', 'stressed', 'A state of mental or emotional strain or tension resulting from adverse or demanding circumstances.', 'Meditate for 3 minutes about the activities you have done today that have caused you stress and think how you could solve it for yourself', '', 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `test`
--

CREATE TABLE `test` (
  `tid` int(11) NOT NULL,
  `respuesta1` int(11) NOT NULL,
  `respuesta2` int(11) NOT NULL,
  `respuesta3` int(11) NOT NULL,
  `respuesta4` int(11) NOT NULL,
  `respuesta5` int(11) NOT NULL,
  `anxiety` double NOT NULL,
  `depression` double NOT NULL,
  `social_anxiety` double NOT NULL,
  `stress` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `test`
--

INSERT INTO `test` (`tid`, `respuesta1`, `respuesta2`, `respuesta3`, `respuesta4`, `respuesta5`, `anxiety`, `depression`, `social_anxiety`, `stress`) VALUES
(2, 1, 1, 1, 11, 1, 1, 1, 11, 11),
(3, 1, 1, 1, 11, 1, 1, 1, 11, 11),
(4, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(5, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(6, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(7, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(8, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(9, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(10, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(11, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(12, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(13, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(14, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(15, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(16, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(17, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(18, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(19, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(20, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(21, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(22, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(23, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(24, 1, 2, 3, 4, 5, 25, 25, 25, 25),
(25, 1, 2, 3, 4, 5, 25, 25, 25, 25);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `test_usuario`
--

CREATE TABLE `test_usuario` (
  `tid` int(11) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `test_usuario`
--

INSERT INTO `test_usuario` (`tid`, `uid`) VALUES
(4, 12),
(5, 14),
(6, 15),
(7, 17),
(8, 18),
(9, 19),
(10, 20),
(11, 21),
(12, 22),
(13, 23),
(14, 24),
(15, 25),
(16, 26),
(17, 27),
(18, 28),
(19, 29),
(20, 30),
(21, 31),
(22, 32),
(23, 33),
(24, 34),
(25, 35);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `email`, `name`, `password`, `Username`) VALUES
(2, 'pep@grr.la', 'pep', '1234', 'peponido'),
(11, 'adribalgo8@grr.la', 'Grinol', '1234', 'adribalgo8'),
(12, 'pepe@grr.la', 'Grinol', '1234', 'Grinol'),
(13, 'pepe@grr.la', 'Grinol', '1234', 'Grinol'),
(14, 'pepe@grr.la', 'Pepe', '1234', 'pepe'),
(15, 'pepe@grr.la', 'Grinol', '1234', 'Grinol'),
(16, 'pepe@grr.la', 'pepe', '1234', 'peponido'),
(17, 'pepe@grr.la', 'pepe', '1234', 'peponido'),
(18, 'pepe@grr.la', 'pepe', '1234', 'pepe'),
(19, 'pepe@grr.la', 'pepe', '1234', 'pepe'),
(20, 'pepe@grr.la', 'pepe', '1234', 'pepe'),
(21, 'Grinol@1', 'Grinol', '1234', 'pepe'),
(22, 'adribalgo8@grr.la', 'adribalgo8', 'adribalgo8', 'adribalgo8'),
(23, 'sexonido@grr.la', 'sexonido', 'sexonido', 'sexonido'),
(24, 'pepelolo@grr.la', 'pepelolo', '1234', 'lolololo'),
(25, 'jominolo@grr.la', 'jominolo', 'jominolo', 'jominolo'),
(26, 'dolera@dolor.com', 'leticiadolera', '1234', 'leti'),
(27, 'kolmon@grr.la', 'kolmon', 'kolmon', 'kolmon'),
(28, 'kolmon1@grr.la', 'kolmon1', 'kolmon1', 'kolmon1'),
(29, 'anfre@mol.com', 'anfre', 'anfre', 'anfre'),
(30, 'anfre1@mol.com', 'anfre1', '1234', 'anfre1'),
(31, 'golardo@mol.com', 'golardo', 'golardo', 'golardo'),
(32, 'Puta@grr.la', 'Puta', 'Puta', 'Puta'),
(33, 'Holido@grr.la', 'Holido', 'Holido', 'Holido'),
(34, 'pepin@grr.la', 'pepin', '1234', 'pepin'),
(35, 'pepin55@grr.la', 'pepin', '1234', 'fino');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`tid`);

--
-- Indices de la tabla `test_usuario`
--
ALTER TABLE `test_usuario`
  ADD PRIMARY KEY (`tid`),
  ADD KEY `resultados` (`uid`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `test`
--
ALTER TABLE `test`
  MODIFY `tid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `test_usuario`
--
ALTER TABLE `test_usuario`
  ADD CONSTRAINT `testid` FOREIGN KEY (`tid`) REFERENCES `test` (`tid`),
  ADD CONSTRAINT `uid` FOREIGN KEY (`uid`) REFERENCES `usuario` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
