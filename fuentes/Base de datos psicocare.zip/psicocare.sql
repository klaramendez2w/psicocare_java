-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 29-11-2018 a las 12:19:46
-- Versión del servidor: 5.7.11
-- Versión de PHP: 5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `psicocare`
--
CREATE DATABASE IF NOT EXISTS `psicocare` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `psicocare`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actividad`
--

CREATE TABLE `actividad` (
  `aid` int(11) NOT NULL,
  `statement` varchar(200) NOT NULL,
  `value` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `test`
--

CREATE TABLE `test` (
  `tid` int(11) NOT NULL,
  `respuesta1` int(11) NOT NULL,
  `respuesta2` int(11) NOT NULL,
  `respuesta3` int(11) NOT NULL,
  `respuesta4` int(11) NOT NULL,
  `respuesta5` int(11) NOT NULL,
  `anxiety` double NOT NULL,
  `depression` double NOT NULL,
  `social_anxiety` double NOT NULL,
  `stress` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `test`
--

INSERT INTO `test` (`tid`, `respuesta1`, `respuesta2`, `respuesta3`, `respuesta4`, `respuesta5`, `anxiety`, `depression`, `social_anxiety`, `stress`) VALUES
(1, 1, 1, 1, 1, 1, 1, 40, 80.4, 100);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `test_usuario`
--

CREATE TABLE `test_usuario` (
  `tid` int(11) NOT NULL,
  `resultados` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `test_usuario`
--

INSERT INTO `test_usuario` (`tid`, `resultados`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `email` varchar(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `password` varchar(11) NOT NULL,
  `test` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id`, `email`, `name`, `password`, `test`) VALUES
(1, 'pepe@grr.la', 'Pepon', '1234', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`tid`);

--
-- Indices de la tabla `test_usuario`
--
ALTER TABLE `test_usuario`
  ADD PRIMARY KEY (`tid`),
  ADD KEY `resultados` (`resultados`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `resultados` (`test`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `test`
--
ALTER TABLE `test`
  ADD CONSTRAINT `test_usuario` FOREIGN KEY (`tid`) REFERENCES `usuario` (`test`);

--
-- Filtros para la tabla `test_usuario`
--
ALTER TABLE `test_usuario`
  ADD CONSTRAINT `test_tid` FOREIGN KEY (`tid`) REFERENCES `test` (`tid`),
  ADD CONSTRAINT `usuario_resultados` FOREIGN KEY (`resultados`) REFERENCES `usuario` (`test`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
